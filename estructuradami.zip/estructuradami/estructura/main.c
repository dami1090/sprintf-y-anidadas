#include <stdio.h>
#include <string.h>
struct fecha
{
    int dia,anio;
    char mes[50];
};
struct gente
{
    char nombre[20];
    struct fecha f_nacimiento;
};
void main(void)
{
    char aux[600];
    struct gente pers;
    struct fecha fn;
    printf("Ingrese nombre: ");
    setbuf(stdin,NULL);
    scanf("%s",pers.nombre);
    printf("Ingrese dia de nacimiento(en numeros): ");
    scanf("%d",&pers.f_nacimiento.dia);
    printf("Ingrese mes de nacimiento(en letras): ");
    setbuf(stdin,NULL);
    scanf("%s",pers.f_nacimiento.mes);
    printf("Ingrese a�o de nacimiento(solo numeros): ");
    scanf("%d",&pers.f_nacimiento.anio);

    sprintf(aux,"se llama %s, y nacio el %d de %s del anio %d",pers.nombre,pers.f_nacimiento.dia,pers.f_nacimiento.mes,pers.f_nacimiento.anio);
    printf("%s",aux);
}
